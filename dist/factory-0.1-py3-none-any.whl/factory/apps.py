from django.apps import AppConfig


class FactoryConfig(AppConfig):
    name = 'factory'
